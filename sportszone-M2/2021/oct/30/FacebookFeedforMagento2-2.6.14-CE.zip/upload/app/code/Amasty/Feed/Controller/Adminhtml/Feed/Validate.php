<?php

namespace Amasty\Feed\Controller\Adminhtml\Feed;

/**
 * empty Class Validate
 * for back compatibility
 * @package Amasty\Feed
 */
class Validate
{

}
