<?php

namespace Amasty\Feed\Model\Indexer\Product;

use Magento\Framework\Indexer\AbstractProcessor;

class ProductFeedProcessor extends AbstractProcessor
{
    const INDEXER_ID = 'amasty_feed_product';
}
