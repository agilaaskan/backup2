<?php

namespace Amasty\Feed\Model\Rule;

/**
 * Class Rule
 */
class Rule extends \Magento\CatalogRule\Model\Rule
{

}
