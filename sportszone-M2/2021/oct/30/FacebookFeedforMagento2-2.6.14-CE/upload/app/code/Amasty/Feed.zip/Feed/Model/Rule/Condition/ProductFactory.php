<?php

namespace Amasty\Feed\Model\Rule\Condition;

/**
 * Class ProductFactory
 */
class ProductFactory extends \Magento\CatalogRule\Model\Rule\Condition\ProductFactory
{
}
