<?php

namespace Magenest\RewardPoints\Plugin;

use Magenest\RewardPoints\Model\Account;
use Magenest\RewardPoints\Model\AccountFactory;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Customer\Model\Session as CustomerSession;

/**
 * Class ConfigProviderPlugin
 *
 * @package Magenest\RewardPoints\Plugin
 */
class ConfigProviderPlugin
{
    /**
     * @var CheckoutSession
     */
    private $checkoutSession;

    /**
     * @var AccountFactory
     */
    protected $_accountFactory;

    /**
     * @var CustomerSession
     */
    private $customerSession;

    /**
     * @var \Magenest\RewardPoints\Helper\Data
     */
    private $helper;

    /**
     * ConfigProviderPlugin constructor.
     *
     * @param CheckoutSession $checkoutSession
     * @param \Magenest\RewardPoints\Helper\Data $helper
     * @param AccountFactory $accountFactory
     * @param CustomerSession $customerSession
     */
    public function __construct(
        CheckoutSession $checkoutSession,
        \Magenest\RewardPoints\Helper\Data $helper,
        AccountFactory $accountFactory,
        CustomerSession $customerSession
    ) {
        $this->_accountFactory = $accountFactory;
        $this->helper          = $helper;
        $this->checkoutSession = $checkoutSession;
        $this->customerSession = $customerSession;
    }

    /**
     * @param \Magento\Checkout\Model\DefaultConfigProvider $subject
     * @param array $result
     *
     * @return array
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function afterGetConfig(\Magento\Checkout\Model\DefaultConfigProvider $subject, array $result)
    {
        if ($this->helper->getEnableModule()) {
            $result['isRewardPointEnable']      = true;
            $quote                              = $this->checkoutSession->getQuote();
            $points                             = $this->helper->getPointsEarn($quote);
            $result['checkoutRewardPointsEarn'] = $points;
            $result['checkoutRewardPointsLabel'] = $this->helper->getPointUnit();
            $rewardPoint                        = intval($quote->getData('reward_point'));
            if ($rewardPoint > 0) {
                $result['checkoutRewardsPointsSpend'] = $rewardPoint;
            } else {
                $result['checkoutRewardsPointsSpend'] = 0;
            }
            $result['earnPointWithAppliedPoints']   = $this->helper->getCanEarnPointWithAppliedPoints();
            $result['earnPointWithAppliedDiscount'] = $this->helper->getCanEarnPointWithAppliedDiscount();
            $customerId             = $this->customerSession->getCustomerId();
            $currentPoint           = $this->getAccount($customerId)->getPointsCurrent();
            $configPoint            = $this->helper->getRewardBaseAmount(null);
            $maximumPoint           = $this->helper->getMaximumPoint();
            $spendingConfigurationEnable          = $this->helper->getSpendingConfigurationEnable();
            $percentMaxOrder        = $this->helper->getPercentMaxOrder();
            $spendingPoint           = $this->helper->getSpendingPoint();
            $upOrDown = $this->helper->getUpOrDown();
            $result['maximumPoint'] = $maximumPoint;
            $result['spendingConfigurationEnable'] = $spendingConfigurationEnable;
            $result['percentMaxOrder'] = $percentMaxOrder;
            $result['spendingPoint'] = $spendingPoint;
            $result['currency']     = $this->checkoutSession->getQuote()->getBaseCurrencyCode();
            $result['configPoint']  = floatval($configPoint);
            $result['currentPoint'] = floatval($currentPoint);
            $result['upOrDown'] = $upOrDown;
        } else {
            $result['isRewardPointEnable'] = false;
        }

        return $result;
    }

    /**
     * @param $customerId
     * @return Account
     */
    public function getAccount($customerId)
    {
        $account = $this->_accountFactory->create()
            ->getCollection()
            ->addFieldToFilter('customer_id', $customerId)
            ->getFirstItem();

        return $account;
    }
}
