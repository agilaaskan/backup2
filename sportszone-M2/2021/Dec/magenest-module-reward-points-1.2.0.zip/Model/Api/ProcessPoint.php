<?php
/**
 * Copyright © 2019 Magenest. All rights reserved.
 * See COPYING.txt for license details.
 * NOTICE OF LICENSE
 *
 * @category Magenest
 */

namespace Magenest\RewardPoints\Model\Api;


use Magenest\RewardPoints\Api\ProcessPointInterface;
use Magenest\RewardPoints\Helper\Data;
use Magento\Customer\Helper\Session\CurrentCustomer;
use Magento\Framework\Controller\ResultFactory;

/**
 * Class ProcessPoint
 * @package Magenest\RewardPoints\Model\Api
 */
class ProcessPoint implements ProcessPointInterface
{
    /**
     * @var \Magento\Framework\Json\Helper\Data
     */
    protected $jsonHelper;

    /**
     * @var \Magento\Checkout\Model\Session
     */
    protected $checkoutSession;

    /**
     * @var CurrentCustomer
     */
    protected $_currentCustomer;

    /**
     * @var Data
     */
    protected $helper;

    /**
     * @var ResultFactory
     */
    protected $resultFactory;

    /**
     * @var \Magenest\RewardPoints\Helper\AddPoint
     */
    protected $addPoint;

    protected $cart;

    /**
     * Checkout constructor.
     * @param \Magento\Framework\Json\Helper\Data $jsonHelper
     * @param CurrentCustomer $currentCustomer
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param Data $helper
     * @param ResultFactory $resultFactory
     * @param \Magenest\RewardPoints\Helper\AddPoint $addPoint
     * @param \Magento\Checkout\Model\Cart $cart
     */
    public function __construct(
        \Magento\Framework\Json\Helper\Data $jsonHelper,
        CurrentCustomer $currentCustomer,
        \Magento\Checkout\Model\Session $checkoutSession,
        Data $helper,
        ResultFactory $resultFactory,
        \Magenest\RewardPoints\Helper\AddPoint $addPoint,
        \Magento\Checkout\Model\Cart $cart
    )
    {
        $this->jsonHelper = $jsonHelper;
        $this->checkoutSession  = $checkoutSession;
        $this->helper           = $helper;
        $this->_currentCustomer = $currentCustomer;
        $this->resultFactory    = $resultFactory;
        $this->addPoint         = $addPoint;
        $this->cart             = $cart;
    }

    /**
     * @return string
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function loadPoint()
    {
        $quote = $this->checkoutSession->getQuote();
        $spendingConfig = $this->helper->getSpendingConfigurationEnable();
        if ($spendingConfig) {
            $this->addPoint->loadPoint($quote);
        }
        //totalReward point from the account
        //Reward points amount that could apply for current cart
        $reward_point = $this->checkoutSession->getQuote()->getData('reward_point');
        $result['rewardPointAmount'] = floatval($reward_point);
        $pointEarned = $this->helper->getPointsEarn($this->checkoutSession->getQuote());
        $result['pointEarned'] = $pointEarned;
        $result['pointLabel'] = $this->helper->getPointUnit();

        return $this->jsonHelper->jsonEncode($result);
    }

    /**
     * @param int $point
     * @return string|null
     */
    public function addPoint($point)
    {
        $this->addPoint->addPoint($point);
        $result = true;
        return $this->jsonHelper->jsonEncode($result);
    }

    /**
     * @return string
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function cancelPoint()
    {
        $quote = $this->checkoutSession->getQuote();
        $quote->setData('reward_point', 0)->save();
        $quote->setData('reward_amount', 0)->save();
        $quote->setData('base_reward_amount', 0)->save();
        $this->cart->getQuote()->collectTotals()->save();
        $result = true;
        return $this->jsonHelper->jsonEncode($result);
    }
}
