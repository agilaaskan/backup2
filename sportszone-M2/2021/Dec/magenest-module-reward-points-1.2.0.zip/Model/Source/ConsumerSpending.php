<?php

namespace Magenest\RewardPoints\Model\Source;

use Magento\Framework\Option\ArrayInterface;

/**
 * Class UpOrDown
 * @package Magenest\RewardPoints\Model\Source
 */
class ConsumerSpending implements ArrayInterface
{
    /**
     * @return array
     */
    public function toOptionArray()
    {
        return [
            [
                'value' => '0',
                'label' => __('-- Please Select --'),
            ],
            [
                'value' => '1',
                'label' => __('The corresponding score'),
            ],
            [
                'value' => '2',
                'label' => __('The number of points in percent')
            ]
        ];
    }
}

