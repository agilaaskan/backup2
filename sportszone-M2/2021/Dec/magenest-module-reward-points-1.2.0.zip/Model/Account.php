<?php

namespace Magenest\RewardPoints\Model;

use Magenest\RewardPoints\Model\ResourceModel\Account as AccountResource;
use Magenest\RewardPoints\Model\ResourceModel\Account\Collection as Collection;
use Magento\Framework\Model\AbstractModel;
use Magento\Framework\Model\Context;
use Magento\Framework\Registry;

/**
 * Class Account
 * @package Magenest\RewardPoints\Model
 */
class Account extends AbstractModel
{
    /**
     * Account constructor.
     *
     * @param Context $context
     * @param Registry $registry
     * @param AccountResource $resource
     * @param Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        AccountResource $resource,
        Collection $resourceCollection,
        $data = []
    ) {
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }
}
