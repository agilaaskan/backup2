<?php

namespace Magenest\RewardPoints\Logger;

/**
 * Class Logger
 * @package Magenest\RewardPoints\Logger
 */
class Logger extends \Monolog\Logger
{
}