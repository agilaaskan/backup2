<?php
/**
 * Copyright © 2018 Magenest. All rights reserved.
 * See COPYING.txt for license details.
 *
 * Magenest_RewardPoints extension
 * NOTICE OF LICENSE
 *
 * @category Magenest
 * @package Magenest_RewardPoints
 */

namespace Magenest\RewardPoints\Setup;

use Magento\Cms\Model\PageFactory;
use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\UpgradeDataInterface;
use Magento\Sales\Setup\SalesSetupFactory;

class UpgradeData implements UpgradeDataInterface
{
    const NAMESPACE_REWARDPOINTS_ACCOUNT_LISTING = 'rewardpoints_account_listing';

    const NAMESPACE_REWARDPOINTS_TRANSACTION_LISTING = 'rewardpoints_transaction_listing';

    /**
     * @var PageFactory
     */
    private $pageFactory;

    /**
     * @var \Magenest\RewardPoints\Setup\RewardPointSetupFactory
     */
    private $rewardPointSetupFactory;

    /**
     * @var SalesSetupFactory
     */
    protected $salesSetupFactory;

    /**
     * @var Resource
     */
    protected $resource;

    /**
     * @var \Magento\Framework\App\State
     */
    protected $state;

    /**
     * @var \Magento\Ui\Model\ResourceModel\Bookmark\CollectionFactory
     */
    protected $bookmarkCollectionFactory;

    /**
     * @var \Magento\Framework\View\Element\Template
     */
    protected $template;

    /**
     * UpgradeData constructor.
     * @param RewardPointSetupFactory $rewardPointSetupFactory
     * @param PageFactory $pageFactory
     * @param \Magento\Framework\App\State $state
     * @param SalesSetupFactory $salesSetupFactory
     * @param \Magento\Framework\App\ResourceConnection $resource
     * @param \Magento\Ui\Model\ResourceModel\Bookmark\CollectionFactory $bookmarkCollectionFactory
     * @param \Magento\Framework\View\Element\Template $template
     */
    public function __construct(
        RewardPointSetupFactory $rewardPointSetupFactory,
        PageFactory $pageFactory,
        \Magento\Framework\App\State $state,
        SalesSetupFactory $salesSetupFactory,
        \Magento\Framework\App\ResourceConnection $resource,
        \Magento\Ui\Model\ResourceModel\Bookmark\CollectionFactory $bookmarkCollectionFactory,
        \Magento\Framework\View\Element\Template $template
    ) {
        $this->salesSetupFactory       = $salesSetupFactory;
        $this->resource                = $resource;
        $this->pageFactory             = $pageFactory;
        $this->rewardPointSetupFactory = $rewardPointSetupFactory;
        $this->state                   = $state;
        $this->bookmarkCollectionFactory = $bookmarkCollectionFactory;
        $this->template = $template;
    }

    public function upgrade(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $this->state->emulateAreaCode(\Magento\Framework\App\Area::AREA_GLOBAL,
            function ($setup, $context) {
                $setup->startSetup();
                if (version_compare($context->getVersion(), '1.0.7') < 0) {
                    $this->addRewardPointAttributes($setup);
                }
                if (version_compare($context->getVersion(), '1.0.8') < 0) {
                    $this->addLandingPage();
                }
                if (version_compare($context->getVersion(), '1.0.8') < 0) {
                    $this->addRefundByPointAttributes($setup);
                }
                if (version_compare($context->getVersion(), '1.1.0') < 0) {
                    $this->clearBookmark($setup);
                }
                $setup->endSetup();
            },
            [$setup, $context]
        );
    }

    private function addRewardPointAttributes($setup)
    {
        $rewardPointSetup = $this->rewardPointSetupFactory->create(['setup' => $setup]);
        $attributes       = [
            'reward_tier' => ['type' => Table::TYPE_DECIMAL],
        ];
        foreach ($attributes as $attributeCode => $attributeParams) {
            $rewardPointSetup->addAttribute('quote', $attributeCode, $attributeParams);

            $rewardPointSetup->addAttribute('quote_address', $attributeCode, $attributeParams);

            $rewardPointSetup->addAttribute('order', $attributeCode, $attributeParams);

            //perhaps invoice and creditmemo do not need hold data of reward point
            $rewardPointSetup->addAttribute('invoice', $attributeCode, $attributeParams);
            $rewardPointSetup->addAttribute('creditmemo', $attributeCode, $attributeParams);
        }
    }

    private function addRefundByPointAttributes($setup)
    {
        $salesInstaller = $this->salesSetupFactory->create(['resourceName' => 'sales_setup', 'setup' => $setup]);

        $salesInstaller->addAttribute('creditmemo', 'bs_customer_mgn_rwp_total_refunded', ['type' => 'decimal']);
        $salesInstaller->addAttribute('creditmemo', 'customer_mgn_rwp_total_refunded', ['type' => 'decimal']);

        $salesInstaller->addAttribute('order', 'bs_customer_mgn_rwp_total_refunded', ['type' => 'decimal']);
        $salesInstaller->addAttribute('order', 'customer_mgn_rwp_total_refunded', ['type' => 'decimal']);

        $this->resource->getConnection('sales_order')->addColumn(
            $setup->getTable('sales_order_grid'),
            'refunded_to_mgn_rwp',
            [
                'TYPE'    => Table::TYPE_DECIMAL,
                'LENGTH'  => '12,4',
                'COMMENT' => 'Refund to Reward Points'
            ]
        );
    }

    private function addLandingPage()
    {
        $pageTemplate = $this->template->setTemplate('Magenest_RewardPoints::landing.phtml')->toHtml();
        $cmsPageData  =
            [
                'is_active'       => 1,
                'title'           => __("Reward Points"),
                'content_heading' => 'Reward Points',
                'content'         => $pageTemplate,
                'identifier'      => 'reward-landing',
                'page_layout'     => '1column',
                'stores'          => [0],
                'sort_order'      => 0
            ];

        $pageModel = $this->pageFactory->create();
        if (isset($cmsPageData)) {
            $id = $pageModel->getResource()->checkIdentifier($cmsPageData['identifier'], 0);
            if ($id) {
                $pageModel->load($id)->addData($cmsPageData)->save();
            } else {
                $pageModel->setData($cmsPageData)->save();
            }
        }
    }

    /**
     * Clear book mark for Points Manager and Transaction History Manager grid
     */
    private function clearBookmark() {
        $bookmarkCollection = $this->bookmarkCollectionFactory->create()
            ->addFieldToFilter('namespace', ['in' => [self::NAMESPACE_REWARDPOINTS_ACCOUNT_LISTING, self::NAMESPACE_REWARDPOINTS_TRANSACTION_LISTING]]);
        if ($bookmarkCollection->getSize()) {
            foreach ($bookmarkCollection as $bookmark) {
                $bookmark->delete();
            }
        }
    }

}
