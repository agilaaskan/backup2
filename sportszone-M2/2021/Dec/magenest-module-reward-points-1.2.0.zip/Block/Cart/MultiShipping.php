<?php

namespace Magenest\RewardPoints\Block\Cart;

use Magento\Checkout\Model\Session as CheckoutSession;

/**
 * Class Js
 * @package Magenest\RewardPoints\Block\Customer
 */
class MultiShipping extends \Magento\Framework\View\Element\Template
{

    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $customerSession;

    /**
     * @var \Magenest\RewardPoints\Model\AccountFactory
     */
    protected $_accountFactory;

    /**
     * @var \Magenest\RewardPoints\Helper\Data
     */
    protected $helper;

    /**
     * @var CheckoutSession
     */
    protected $checkoutSession;

    /**
     * @var \Magento\Checkout\Model\Cart
     */
    protected $cart;

    /**
     * @var \Magenest\RewardPoints\Helper\AddPoint
     */
    protected $addPoint;

    /**
     * MultiShipping constructor.
     * @param \Magento\Customer\Model\Session $customerSession
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Magenest\RewardPoints\Model\AccountFactory $accountFactory
     * @param \Magenest\RewardPoints\Helper\Data $helper
     * @param CheckoutSession $checkoutSession
     * @param \Magento\Checkout\Model\Cart $cart
     * @param \Magenest\RewardPoints\Helper\AddPoint $addPoint
     * @param array $data
     */
    public function __construct(
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Framework\View\Element\Template\Context $context,
        \Magenest\RewardPoints\Model\AccountFactory $accountFactory,
        \Magenest\RewardPoints\Helper\Data $helper,
        CheckoutSession $checkoutSession,
        \Magento\Checkout\Model\Cart $cart,
        \Magenest\RewardPoints\Helper\AddPoint $addPoint,
        array $data = []
    ) {
        $this->customerSession = $customerSession;
        $this->_accountFactory = $accountFactory;
        $this->helper = $helper;
        $this->checkoutSession = $checkoutSession;
        $this->cart = $cart;
        $this->addPoint         = $addPoint;
        parent::__construct($context, $data);
    }

    /**
     * @return \Magento\Customer\Model\Session
     */
    public function currentPoint()
    {
        $customerId = $this->customerSession->getCustomerId();
        $currentPoint = $this->getAccount($customerId)->getPointsCurrent();
        return $currentPoint;
    }

    public function getAccount($customerId)
    {
        $account = $this->_accountFactory->create()
            ->getCollection()
            ->addFieldToFilter('customer_id', $customerId)
            ->getFirstItem();

        return $account;
    }

    public function getConfigPoint() {
        return $this->helper->getRewardBaseAmount(null);
    }

    /**
     * @return string
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getCurrency() {
        return $this->checkoutSession->getQuote()->getBaseCurrencyCode();
    }

    /**
     * @return float|int|\Magento\Customer\Model\Session|mixed
     */
    public function getMaxAppliedPoint() {
        $quote = $this->cart->getQuote();
        $baseSubtotal = $quote->getData('base_subtotal');
        $maximumPoint = $this->helper->getMaximumPoint();
        $couponCode = $quote->getData('coupon_code');
        if ($couponCode) {
            $subtotalWithDiscount = $quote->getData('subtotal_with_discount');
        }
        //Get data in config
        $spendingConfigurationEnable = $this->helper->getSpendingConfigurationEnable();
        $percentMaxOrder = $this->helper->getPercentMaxOrder();
        $spendingPoint = $this->helper->getSpendingPoint();
        $rewardAmount = 0;

        //Where customers use config in spending
        if ($spendingConfigurationEnable == 1) {
            //Spending by %
            if ($percentMaxOrder != 0 && $spendingPoint == 2) {
                $percent = $percentMaxOrder / 100;
                if ($couponCode && isset($subtotalWithDiscount)) {
                    $grandTotal2 = ceil($subtotalWithDiscount * $percent);
                } else {
                    $grandTotal2 = ceil($baseSubtotal * $percent);
                }
                $maxAppliedPoint = $grandTotal2;
            } else {
                //Spending by admin review points
                $grandTotal2 = $baseSubtotal;
                $grandTotal = $grandTotal2 - $rewardAmount;
                $currentPoint = $this->currentPoint();
                $convertRatio = $this->getConfigPoint();
                if ($currentPoint >= $grandTotal) {
                    //Consider the case of coupon use
                    if (isset($subtotalWithDiscount)) {
                        $maxAppliedPoint = $subtotalWithDiscount;
                    } else {
                        $maxAppliedPoint = $grandTotal * $convertRatio;
                    }
                } else {
                    $maxAppliedPoint = $currentPoint;
                }
            }
            //The case of using fixed points according to config
            if ($maximumPoint != 0 && $spendingPoint == 1) {
                if ($maxAppliedPoint > $maximumPoint) {
                    $maxAppliedPoint = $maximumPoint;
                    if ($quote->getData('reward_point') != 0) {
                        $this->updateQuote($quote, $maxAppliedPoint);
                    }
                }
            }
        } else {
            if (isset($subtotalWithDiscount)) {
                $maxAppliedPoint = $subtotalWithDiscount;
            } else {
                $maxAppliedPoint = $baseSubtotal;
            }
        }
        //Without using a coupon
        if (isset($subtotalWithDiscount) && $subtotalWithDiscount == 0) {
            $maxAppliedPoint = 0;
        }
        if ($this->helper->getUpOrDown() == 'up') {
            return ceil($maxAppliedPoint);
        } else {
            return floor($maxAppliedPoint);
        }
    }

    /**
     * @return mixed|string
     */
    public function getRewardPoint() {
        $quote = $this->cart->getQuote();
        $spendingConfig = $this->helper->getSpendingConfigurationEnable();
        //Check Spending Configuration In Backend
        if ($spendingConfig) {
            $this->addPoint->loadPoint($quote);
        }
        //Get point in table quote
        $rewardPoint = $quote->getData('reward_point');
        if ($rewardPoint == 0 || $rewardPoint == null) {
            $rewardPoint = '';
        }
        $arr = explode('.' , $rewardPoint);
        $rewardPoint = reset($arr);
        return $rewardPoint;
    }

    /**
     * @param $quote
     * @param $point
     */
    public function updateQuote($quote, $point) {
        $quote->setData('reward_point', $point);
        $quote->setData('base_reward_amount', $point);
        $quote->setData('reward_amount', $point);
        $quote->save();
    }
}
