<?php
/**
 * Copyright © 2018 Magenest. All rights reserved.
 * See COPYING.txt for license details.
 *
 * Magenest_ReferAFriend extension
 * NOTICE OF LICENSE
 *
 * @category Magenest
 * @package  Magenest_RewardPoints
 */

namespace Magenest\RewardPoints\Observer;

use Magento\Framework\Event\ObserverInterface;

class Referral implements ObserverInterface
{
    const COOKIE_NAME = 'referralcode';

    /**
     * @var \Magenest\RewardPoints\Cookie\ReferralCode
     */
    protected $referralCodeCookie;

    /**
     * @var \Magenest\RewardPoints\Helper\Data
     */
    protected $referHelper;

    /**
     * @var \Magento\Framework\UrlInterface
     */
    protected $url;

    /**
     * Referral constructor.
     * @param \Magenest\RewardPoints\Cookie\ReferralCode $referralCodeCookie
     * @param \Magenest\RewardPoints\Helper\Data $referHelper
     * @param \Magento\Framework\UrlInterface $url
     */
    public function __construct(
        \Magenest\RewardPoints\Cookie\ReferralCode $referralCodeCookie,
        \Magenest\RewardPoints\Helper\Data $referHelper,
        \Magento\Framework\UrlInterface $url
    ) {
        $this->referralCodeCookie = $referralCodeCookie;
        $this->referHelper = $referHelper;
        $this->url = $url;
    }

    /**
     * @param \Magento\Framework\Event\Observer $observer
     * @throws \Magento\Framework\Exception\InputException
     * @throws \Magento\Framework\Stdlib\Cookie\CookieSizeLimitReachedException
     * @throws \Magento\Framework\Stdlib\Cookie\FailureToSendException
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        if (!$this->referHelper->isReferByLinkEnabled()) {
            return;
        }

        $referralCode = $observer->getEvent()->getRequest()->getParam(self::COOKIE_NAME);
        if ($referralCode === null) {
            return;
        }

        $customerCode = $this->referHelper->getReferralCode();
        if ($referralCode === $customerCode) {
            return;
        }

        $referUrl = $this->url->getBaseUrl() . $this->referHelper->getReferPath() . '?referralcode=' . $referralCode;
        $currentUrl = $this->url->getCurrentUrl();
        if (strpos($currentUrl, $referUrl) === false) {
            return;
        }

        $this->referralCodeCookie->delete();
        $this->referralCodeCookie->set($referralCode);
    }
}
