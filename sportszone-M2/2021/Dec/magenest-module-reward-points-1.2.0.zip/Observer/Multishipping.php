<?php

namespace Magenest\RewardPoints\Observer;

use Magento\Backend\App\ConfigInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\CatalogRule\Model\RuleFactory as CoreRuleFactory;

/**
 * Class PlaceOrder
 * @package Magenest\RewardPoints\Observer
 */
class Multishipping implements ObserverInterface
{
    /**
     * @var \Magento\Framework\Message\ManagerInterface
     */
    protected $messageManager;

    /**
     * @var StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * @var CoreRuleFactory
     */
    protected $_coreRuleFactory;

    /**
     * @var \Magento\Quote\Model\QuoteFactory
     */
    protected $quoteFactory;

    /**
     * @var ConfigInterface
     */
    protected $_config;

    /**
     * @var \Magento\Checkout\Model\Session
     */
    protected $checkoutSession;

    /**
     * @var \Magenest\RewardPoints\Helper\Data
     */
    protected $_hlp;

    /**
     * Multishipping constructor.
     * @param ConfigInterface $config
     * @param \Magento\Framework\Message\ManagerInterface $messageManager
     * @param StoreManagerInterface $storeManagerInterface
     * @param CoreRuleFactory $coreRuleFactory
     * @param \Magento\Quote\Model\QuoteFactory $quoteFactory
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param \Magenest\RewardPoints\Helper\Data $hlp
     */
    public function __construct(
        ConfigInterface $config,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        StoreManagerInterface $storeManagerInterface,
        CoreRuleFactory $coreRuleFactory,
        \Magento\Quote\Model\QuoteFactory $quoteFactory,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magenest\RewardPoints\Helper\Data $hlp
    ) {
        $this->_config             = $config;
        $this->quoteFactory        = $quoteFactory;
        $this->messageManager      = $messageManager;
        $this->_coreRuleFactory    = $coreRuleFactory;
        $this->_storeManager       = $storeManagerInterface;
        $this->checkoutSession    = $checkoutSession;
        $this->_hlp = $hlp;
    }

    /**
     * @param Observer $observer
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function execute(Observer $observer)
    {
        $order  = $observer->getEvent()->getQuote();
        $extensionAttributes = count($order->getData('extension_attributes')->getShippingAssignments());
        if ($extensionAttributes > 1) {
            $rewardPoint = $order->getData('reward_point');
            $upOrDown = $this->_hlp->getUpOrDown();
            $pointMoney = $this->_hlp->getRewardBaseAmount();
            if ($upOrDown === 'up') {
                $point = ceil($rewardPoint / $extensionAttributes) / $pointMoney;
            } else {
                $point = floor($rewardPoint / $extensionAttributes) / $pointMoney;
            }
            $quote = $this->checkoutSession->getQuote();
            $quote->setData('reward_point', $point)->save();
            $quote->setData('reward_amount', $point)->save();
            $quote->setData('base_reward_point', $point)->save();
        }
    }
}
