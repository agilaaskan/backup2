define(
    [
        'Magento_Checkout/js/view/summary/abstract-total',
        'Magento_Checkout/js/model/quote',
        'jquery',
        'ko',
        'mage/translate'
    ],
    function (Component, quote, $, ko) {
        return Component.extend({
            defaults: {
                pointEarn: 0,
                pointsLabel: '',
                isDisplayedPoints: false
            },
            initObservable: function () {
                var self = this;
                self._super().observe(['pointsLabel', 'pointEarn', 'isDisplayedPoints']);
                self.pointEarn(self.getValue());
                self.pointsLabel(self.getPointUnit());

                this.isDisplayedPoints = ko.pureComputed(function () {
                    return !!self.pointEarn() && parseFloat(self.pointEarn()) > 0.00;
                });

                return this;
            },

            totals: quote.getTotals(),

            getValue: function () {
                return window.checkoutConfig.checkoutRewardPointsEarn;
            },

            getPointUnit: function () {
                return window.checkoutConfig.checkoutRewardPointsLabel;
            }
        });
    }
);