var config = {
    'config':{
        'mixins': {
            'Magento_SalesRule/js/view/payment/discount': {
                'Magenest_RewardPoints/js/view/payment/discount':true
            }
        }
    }
};