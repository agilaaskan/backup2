# README
Thank you for buying our product.
This extension adheres to [Magenest](http://magenest.com/).

### User guide
- If you have trouble installing this extension, please visit: http://www.confluence.izysync.com/display/DOC/1.+Reward+Point+Installation+Guides
- For the detailed user guide of this extension, please visit: http://www.confluence.izysync.com/display/DOC/2.+Reward+Point+User+Guide
- Support portal: http://servicedesk.izysync.com/servicedesk/customer/portal/18 
- Changes and updates to this module are included in CHANGELOG.md file.
