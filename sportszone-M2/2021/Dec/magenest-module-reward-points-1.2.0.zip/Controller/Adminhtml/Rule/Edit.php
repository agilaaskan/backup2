<?php

namespace Magenest\RewardPoints\Controller\Adminhtml\Rule;

use Magenest\RewardPoints\Controller\Adminhtml\Rule;
use Magenest\RewardPoints\Model\RuleFactory;
use Magento\Backend\App\Action;
use Magento\Framework\Registry;
use Magento\Framework\View\Result\PageFactory;

/**
 * Class Edit
 * @package Magenest\RewardPoints\Controller\Adminhtml\Rule
 */
class Edit extends Rule
{
    /**
     * @var \Magento\Backend\Model\Session
     */
    protected $backendSession;

    /**
     * Edit constructor.
     *
     * @param Action\Context $context
     * @param PageFactory $pageFactory
     * @param RuleFactory $ruleFactory
     * @param Registry $registry
     */
    public function __construct(
        Action\Context $context,
        PageFactory $pageFactory,
        RuleFactory $ruleFactory,
        Registry $registry
    ) {
        $this->backendSession = $context->getSession();
        parent::__construct($context, $pageFactory, $ruleFactory, $registry);
    }

    /**
     * @return \Magento\Backend\Model\View\Result\Page|\Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\Result\Redirect|\Magento\Framework\Controller\ResultInterface
     * @throws \Zend_Json_Exception
     */
    public function execute()
    {
        $id = $this->getRequest()->getParam('id');
        /** @var \Magenest\RewardPoints\Model\Rule $model */
        $model = $this->_ruleFactory->create();

        if ($id) {
            $model->load($id);

            if (!$model->getId()) {
                $this->messageManager->addError(__('This rule doesn\'t exist'));

                $resultRedirect = $this->resultRedirectFactory->create();

                return $resultRedirect->setPath('*/*/');
            }
        }

        $data = $this->backendSession->getFormData(true);
        if (!empty($data)) {
            $model->setData($data);
        }
        if ($model->getCondition() == 'firstpurchase')
            $model->setMinimumAmount($model->getConditions()->getConditions()[0]->getValue());
        if (\Magenest\RewardPoints\Helper\Data::isReferAFriendModuleEnabled())
            $this->_eventManager->dispatch('registry_add_points_referred', ['rule' => $model]);
        if ($model->getCondition() == 'grateful')
            $model->setCustomerNumber($model->getConditions()->getConditions()[0]->getValue());

        // add additional configuration
        $ruleConfigs = $model->getRuleConfigs();
        if (!empty($ruleConfigs)) {
            $ruleConfigs = \Zend_Json::decode($ruleConfigs);
            if (!empty($ruleConfigs)) {
                foreach ($ruleConfigs as $key => $value) {
                    $name = 'rule_configs[' . $key . ']';
                    $model->setData($name, $value);
                }
            }
        }
        // end

        $this->_coreRegistry->register('rewardpoints_rule', $model);
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->_initAction();
        $resultPage->getConfig()->getTitle()
            ->prepend($model->getId() ? __('Edit Rule \'%1\'', $model->getData('title')) : __('New Reward Points Rule'));

        return $resultPage;
    }
}
