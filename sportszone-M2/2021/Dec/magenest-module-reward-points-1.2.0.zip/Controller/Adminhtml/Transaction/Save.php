<?php

namespace Magenest\RewardPoints\Controller\Adminhtml\Transaction;

use Magento\Backend\App\Action;
use Magento\Framework\Exception\LocalizedException;

/**
 * Class Save
 * @package Magenest\RewardPoints\Controller\Customer
 */
class Save extends Action
{

    /**
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    protected $_resultJsonFactory;

    /**
     * @var \Magenest\RewardPoints\Helper\Data
     */
    protected $helper;

    /**
     * @var \Magento\Backend\Model\Auth\Session
     */
    protected $authSession;

    /**
     * @var \Magenest\RewardPoints\Model\TransactionFactory
     */
    protected $transactionFactory;

    /**
     * @var \Magento\Backend\Model\SessionFactory
     */
    protected $sessionFactory;

    /**
     * Save constructor.
     * @param \Magenest\RewardPoints\Helper\Data $help
     * @param \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
     * @param Action\Context $context
     * @param \Magento\Backend\Model\Auth\Session $authSession
     * @param \Magenest\RewardPoints\Model\TransactionFactory $transactionFactory
     */
    public function __construct(
        \Magenest\RewardPoints\Helper\Data $help,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        Action\Context $context,
        \Magento\Backend\Model\Auth\Session $authSession,
        \Magenest\RewardPoints\Model\TransactionFactory $transactionFactory,
        \Magento\Backend\Model\SessionFactory $sessionFactory
    )
    {
        $this->helper            = $help;
        $this->_resultJsonFactory = $resultJsonFactory;
        $this->authSession = $authSession;
        $this->transactionFactory = $transactionFactory;
        $this->sessionFactory = $sessionFactory;
        parent::__construct($context);
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\Result\Json|\Magento\Framework\Controller\ResultInterface
     * @throws \Exception
     */
    public function execute()
    {
        $data            = $this->getRequest()->getParams();
        $data['rule_id'] = -1;
        $success = true;
        if ($data) {
            $model = $this->transactionFactory->create();
            $model->setData($data)->save();
            $pointAfter = $this->helper->addPointsAccount($model->getCustomerId(), $model->getPointsChange(), $model->getId());

            try {
                $model->setData('points_after', $pointAfter);
                $ruleId = $model->getRuleId();
                if ($ruleId == -1) {
                    $auth = $this->authSession->getUser();
                    $firstNameAdmin = $auth->getData('firstname');
                    $comment = 'Admin' . '(' . $firstNameAdmin . ')' . ' - ' . $model->getComment();
                    $model->setData('comment', $comment);
                }
                $model->save();
            } catch (LocalizedException $e) {
                $success = false;

            } catch (\Exception $e) {
                $success = false;

            }
        }
        $resultJson = $this->_resultJsonFactory->create();

        if ($pointAfter === 0) {
            return $resultJson->setData([
                'success'=>$success,
                'depleted'=>true,
            ]);
        }

        return $resultJson->setData(['success'=>$success]);
    }

}
