<?php
/**
 *  Canada Post Shipping Module.
 *
 * @category  Shipping & Fulfillment
 * @package   Rootways_Canadapost
 * @author    Developer RootwaysInc <developer@rootways.com>
 * @copyright 2020 Rootways Inc. (https://www.rootways.com)
 * @license   Rootways Custom License
 * @link      https://www.rootways.com/pub/media/extension_doc/license_agreement.pdf
 */

namespace Rootways\Canadapost\Model;

use Magento\Framework\App\ObjectManager;
use Magento\Framework\Xml\Security;
use Magento\Quote\Model\Quote\Address\RateRequest;
use Magento\Shipping\Model\Carrier\AbstractCarrierOnline;
use Magento\Shipping\Model\Rate\Result;
use Magento\Shipping\Model\Rate\Result\ProxyDeferredFactory;

/**
 * Rootways Canadapost shipping
 */
class Carrier extends AbstractCarrierOnline implements \Magento\Shipping\Model\Carrier\CarrierInterface
{
    /**
     * @var string
     */
    protected $_code = 'rwcanadapost';
    
    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;
    
    /**
     * @var \Magento\Quote\Model\Quote\Address\RateResult\MethodFactory
     */
    protected $rateMethodFactory;
    
    /**
     * @var \Magento\Shipping\Model\Rate\ResultFactory
     */
    protected $rateResultFactory;
    
    /**
     * @var array
     */
    protected $type;
    
    /**
     * @param \Rootways\Canadapost\Helper\Data $customHelper
     * @param \Magento\Framework\Stdlib\DateTime\TimezoneInterface $dateTime
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Quote\Model\Quote\Address\RateResult\ErrorFactory $rateErrorFactory
     * @param \Psr\Log\LoggerInterface $logger
     * @param Security $xmlSecurity
     * @param \Magento\Shipping\Model\Simplexml\ElementFactory $xmlElFactory
     * @param \Magento\Shipping\Model\Rate\ResultFactory $rateFactory
     * @param \Magento\Quote\Model\Quote\Address\RateResult\MethodFactory $rateMethodFactory
     * @param \Magento\Shipping\Model\Tracking\ResultFactory $trackFactory
     * @param \Magento\Shipping\Model\Tracking\Result\ErrorFactory $trackErrorFactory
     * @param \Magento\Shipping\Model\Tracking\Result\StatusFactory $trackStatusFactory
     * @param \Magento\Directory\Model\RegionFactory $regionFactory
     * @param \Magento\Directory\Model\CountryFactory $countryFactory
     * @param \Magento\Directory\Model\CurrencyFactory $currencyFactory
     * @param \Magento\Directory\Helper\Data $directoryData
     * @param \Magento\CatalogInventory\Api\StockRegistryInterface $stockRegistry
     */
    public function __construct(
        \Rootways\Canadapost\Helper\Data $customHelper,
        \Magento\Catalog\Model\ProductRepository $productRepository,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $dateTime,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Quote\Model\Quote\Address\RateResult\ErrorFactory $rateErrorFactory,
        \Psr\Log\LoggerInterface $logger,
        Security $xmlSecurity,
        \Magento\Shipping\Model\Simplexml\ElementFactory $xmlElFactory,
        \Magento\Shipping\Model\Rate\ResultFactory $rateFactory,
        \Magento\Quote\Model\Quote\Address\RateResult\MethodFactory $rateMethodFactory,
        \Magento\Shipping\Model\Tracking\ResultFactory $trackFactory,
        \Magento\Shipping\Model\Tracking\Result\ErrorFactory $trackErrorFactory,
        \Magento\Shipping\Model\Tracking\Result\StatusFactory $trackStatusFactory,
        \Magento\Directory\Model\RegionFactory $regionFactory,
        \Magento\Directory\Model\CountryFactory $countryFactory,
        \Magento\Directory\Model\CurrencyFactory $currencyFactory,
        \Magento\Directory\Helper\Data $directoryData,
        \Magento\CatalogInventory\Api\StockRegistryInterface $stockRegistry,
        array $data = []
    ) {
        $this->_rateErrorFactory = $rateErrorFactory;
        $this->_rateResultFactory = $rateFactory;
        $this->_rateMethodFactory = $rateMethodFactory;
        $this->customHelper = $customHelper;
        $this->_productRepository = $productRepository;
        $this->_localeDate = $dateTime;
        $this->_trackErrorFactory = $trackErrorFactory;
        parent::__construct(
            $scopeConfig,
            $rateErrorFactory,
            $logger,
            $xmlSecurity,
            $xmlElFactory,
            $rateFactory,
            $rateMethodFactory,
            $trackFactory,
            $trackErrorFactory,
            $trackStatusFactory,
            $regionFactory,
            $countryFactory,
            $currencyFactory,
            $directoryData,
            $stockRegistry,
            $data
        );
    }
    
    public function getAllowedMethods()
    {
        $allowed = explode(",", $this->customHelper->getAllowedMethods());
        $arr = [];
        foreach ($allowed as $k) {
            $arr[$k] = $this->getCode('method', $k);
        }
        
        return $arr;
    }
    
    public function collectRates(RateRequest $request)
    {
        if ( !$this->getConfigFlag('active') ) {
            return false;
        }
 
        /** @var \Magento\Shipping\Model\Rate\Result $result */
        $result = $this->_rateResultFactory->create();
        
        $apiKey = $this->customHelper->getApiKey();
        $password = $this->customHelper->getPassword();
        $customer = $this->customHelper->getCustomerNumber();
        
        $destCountryId = $request->getDestCountryId();
	    $zip_code = trim(preg_replace('/\s+/', '', $request->getDestPostcode()));
	    $zip = strtoupper($zip_code);
		
        if ($request->getOrigCountry()) {
            $sourceCountry = $request->getOrigCountry();
        } else {
            $sourceCountry = $this->_scopeConfig->getValue(
                \Magento\Sales\Model\Order\Shipment::XML_PATH_STORE_COUNTRY_ID,
                \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
                $request->getStoreId()
            );
        }
        if ($request->getOrigPostcode()) {
        	$oripost = $request->getOrigPostcode();
            $originpost = trim(preg_replace('/\s+/', '', $oripost));
        } else {
            $oripost = $this->_scopeConfig->getValue(
                \Magento\Sales\Model\Order\Shipment::XML_PATH_STORE_ZIP,
                \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
                $request->getStoreId()
            );
            $originpost = trim(preg_replace('/\s+/', '', $oripost));
        }
        
        $price = 0;
        $w = 0;
        foreach ($request->getAllItems() as $item) {
            $q = $item->getQty();
            $price = $price+($item->getPrice())*$q;
            $w = $w+($item->getWeight())*$q;
        }
        
        $weightUnit = $this->customHelper->getWeightUnit();
        $weight = $this->convertWeightToKg($w, $weightUnit);
        $allowFreeShip = 0;
        if ($this->customHelper->getConfig('carriers/rwcanadapost/free_shipping_enable')
            && $this->customHelper->getConfig('carriers/rwcanadapost/free_shipping_subtotal') != '') {
            if ($price >= $this->customHelper->getConfig('carriers/rwcanadapost/free_shipping_subtotal')) {
                $allowFreeShip = 1;
            }
        }
        
        if ($price >5000 && $destCountryId=="CA") {
            return false;
        } 
        if ($price >1000 && $destCountryId!="CA") {
            return false;
        }
        if ($price <=0 OR $w==0) {        	 
            return false;
        }
        if ($sourceCountry !="CA") {
            return false;
        }
        
        if ($destCountryId == 'CA') {
            $destination = [
                'domestic' => [
                    'postal-code' => $zip
                ]
            ];
        } else if ($destCountryId=='US') {
            $destination = [
                'united-states' => [
                    'zip-code' => $zip
                ]
            ];
        } else {
             $destination = [
                'international' => [
                    'country-code' => $destCountryId
                ]
            ];
        }
        
        $mailing_scenario = [
            'customer-number' => $this->customHelper->getCustomerNumber(),
            'parcel-characteristics' => [
                'weight' => $weight,
                'unpackaged' => false,
                'mailing-tube'=> false
            ],
            'origin-postal-code' => $originpost,
            'destination' => $destination
        ];
        
        $length = $this->customHelper->getConfig('carriers/rwcanadapost/default_length');
        $width = $this->customHelper->getConfig('carriers/rwcanadapost/default_width');
        $height = $this->customHelper->getConfig('carriers/rwcanadapost/default_height');
        if ($length || $width || $height) {
            $mailing_scenario['parcel-characteristics']['dimensions'] = [
                'length'    => round($length, 1),
                'width'     => round($width, 1),
                'height'    => round($height, 1)
            ];
        }
        
        $params = [
            'get-rates-request' => [
                'locale' => $this->customHelper->getLocale(),
                'mailing-scenario' => $mailing_scenario
            ]
        ];
        
        $wsdlFileName = '/libcanadapost/wsdl/rating.wsdl';
        $client = $this->_createSoapClient($wsdlFileName, 'rating');
        $response = $client->__soapCall('GetRates', $params, null, null);
        //file_put_contents('vish_canadapost_response.txt', print_r($response, true), FILE_APPEND);
        $errorMsg = '';
        if (isset($response->{'price-quotes'})) {
            $allowedMethods = explode(",", $this->customHelper->getAllowedMethods());
            foreach ($response->{'price-quotes'}->{'price-quote'} as $priceQuote ) {
                $method = (string)$priceQuote->{'service-code'};
                if (in_array($method, $allowedMethods)) {
                    $title = $priceQuote->{'service-name'};
                    if ($this->customHelper->getConfig('carriers/rwcanadapost/show_delivery_date')) {
                        if (isset($priceQuote->{'service-standard'}->{'expected-delivery-date'})) {
                            $title .= ' - ' .
                                __('Est. Delivery %1',
                                   $this->_localeDate->formatDateTime(
                                       $priceQuote->{'service-standard'}->{'expected-delivery-date'},
                                       \IntlDateFormatter::MEDIUM,
                                       \IntlDateFormatter::NONE
                                   ));
                        }
                    }
                    
                    if ($this->customHelper->getConfig('carriers/rwcanadapost/rates_price_type')) {
                        $price = $priceQuote->{'price-details'}->{'due'}; // Including Tax
                    } else {
                        $price = $priceQuote->{'price-details'}->{'base'}; // Excluding Tax
                        if (isset($priceQuote->{'price-details'}->{'adjustments'})) {
                            foreach ($priceQuote->{'price-details'}->{'adjustments'}->{'adjustment'} as $adjustment) {
                                $price += $adjustment->{'adjustment-cost'};
                            }
                        }
                    }
                    if ($allowFreeShip == 1) {
                        if($this->calculateFeeShippingMethod($method, $destCountryId)) {
                            $price = 0.00;
                            $title = __('Free Shipping'). ' - '. $title;
                        }
                    }
                    $result->append($this->_getDefaultRate($price, $method, $title));
                }
            }
            
        } else {
            $errorMsg = $this->getConfigData('specificerrmsg');
            if ($this->customHelper->getConfig('carriers/rwcanadapost/show_original_message')) {
                if (is_array($response)) {
                    if (isset($response['error_message'])) {
                        $errorMsg = $response['error_message'];
                    }
                }
                if (isset($response->{'messages'})) {
                    foreach ($response->{'messages'}->{'message'} as $message) {
                        $errorMsg = $message->code.': '.$message->description;
                    }
                }
            }
        }
        
        if ($errorMsg) {
            $error = $this->_rateErrorFactory->create();
            $error->setCarrier($this->_code);
            $error->setCarrierTitle($this->getConfigData('title'));
            $error->setErrorMessage($errorMsg);
            $result->append($error);
        }  
        return $result;
    }
    
    public function processAdditionalValidation(\Magento\Framework\DataObject $request)
    {
        //Skip by item validation if there is no items in request
        if (!count($this->getAllItems($request))) {
            return $this;
        }

        $maxAllowedWeight = (double)$this->getConfigData('max_package_weight');
        $weightUnit = $this->customHelper->getWeightUnit();
        $errorMsg = '';
        $configErrorMsg = $this->getConfigData('specificerrmsg');
        $defaultErrorMsg = __('Exceed weight limit for Canada Post shipping. The weight of each piece must be less than or equal to %1 KG', $maxAllowedWeight);
        $showMethod = $this->getConfigData('showmethod');

        /** @var $item \Magento\Quote\Model\Quote\Item */
        foreach ($this->getAllItems($request) as $item) {
            $product = $item->getProduct();
            if ($product && $product->getId()) {
                $weight = $this->convertWeightToKg($product->getWeight(), $weightUnit);
                $stockItemData = $this->stockRegistry->getStockItem(
                    $product->getId(),
                    $item->getStore()->getWebsiteId()
                );
                $doValidation = true;

                if ($stockItemData->getIsQtyDecimal() && $stockItemData->getIsDecimalDivided()) {
                    if ($stockItemData->getEnableQtyIncrements() && $stockItemData->getQtyIncrements()
                    ) {
                        $weight = $weight * $stockItemData->getQtyIncrements();
                    } else {
                        $doValidation = false;
                    }
                } elseif ($stockItemData->getIsQtyDecimal() && !$stockItemData->getIsDecimalDivided()) {
                    $weight = $weight * $item->getQty();
                }

                if ($doValidation && $weight > $maxAllowedWeight) {
                    //$errorMsg = $configErrorMsg ? $configErrorMsg : $defaultErrorMsg;
                    $errorMsg = $defaultErrorMsg;
                    break;
                }
            }
        }

        if (!$errorMsg && !$request->getDestPostcode() && $this->isZipCodeRequired($request->getDestCountryId())) {
            $errorMsg = __('This shipping method is not available. Please specify the zip code.');
        }

        if ($errorMsg && $showMethod) {
            $error = $this->_rateErrorFactory->create();
            $error->setCarrier($this->_code);
            $error->setCarrierTitle($this->getConfigData('title'));
            $error->setErrorMessage($errorMsg);

            return $error;
        } elseif ($errorMsg) {
            return false;
        }

        return $this;
    }
    
    /**
     * @return boolean
     */
    public function isTrackingAvailable()
    {
        return true;
    }
    
    /**
     * @return boolean
     */
    public function isShippingLabelsAvailable()
    {
        return true;
    }
    
    public function _getDefaultRate($price, $method, $title)
    {
        $finalPrice = $this->calculateHandlingFee($price);
        $rate = $this->_rateMethodFactory->create();
        $rate->setCarrier($this->_code);
        $rate->setCarrierTitle($this->getConfigData('title'));
        $rate->setMethod($method);
        $rate->setMethodTitle($title);
        $rate->setCost($finalPrice);
        $rate->setPrice($finalPrice);
        return $rate;
    }
    
    public function calculateFeeShippingMethod($method, $destCountryId)
    {
        $freeShip = 0;
        if ($destCountryId == 'CA') {
            if ($this->customHelper->getConfig('carriers/rwcanadapost/free_method_ca') == $method) {
                $freeShip = 1;
            }
        } else if ($destCountryId == 'US') {
            if ($this->customHelper->getConfig('carriers/rwcanadapost/free_method_us') == $method) {
                $freeShip = 1;
            }
        } else {
            if ($this->customHelper->getConfig('carriers/rwcanadapost/free_method_international') == $method) {
                $freeShip = 1;
            }
        }
        return $freeShip;
    }
    
    public function calculateHandlingFee($price)
    {
        $handlingType = $this->customHelper->getConfig('carriers/rwcanadapost/handling_type');
        $handlingFee = $this->customHelper->getConfig('carriers/rwcanadapost/handling_fee');
        $finalPrice = $price;
        if ($handlingFee != '' && $handlingType == \Magento\Shipping\Model\Carrier\AbstractCarrier::HANDLING_TYPE_FIXED) {
            $finalPrice = $price + $handlingFee;
            //$finalPrice = ($price + $handlingFee) * $this->_numBoxes; // Userful when want to apply handling fee per package instaled of per order.
        }
        
        if ($handlingFee != '' && $handlingType == \Magento\Shipping\Model\Carrier\AbstractCarrier::HANDLING_TYPE_PERCENT) {
            $finalPrice = $price + ($price * $handlingFee / 100);
            //$finalPrice = $price + ($price * $handlingFee / 100) * $this->_numBoxes; // Userful when want to apply handling fee per package instaled of per order.
        }
        return $finalPrice;
    }
    
    public function getCode($type, $code = '')
    {
        $codes = [
            'method' => [
                // Canada
                'DOM.RP'        => __('Regular Parcel'),
                'DOM.EP'        => __('Expedited Parcel'),
                'DOM.LIB'       => __('Library Materials/Books'),
                'DOM.PC'        => __('Priority'),
                'DOM.XP'        => __('Xpresspost'),
                'DOM.XP.CERT'   => __('Xpresspost Certified'),
                //USA
                'USA.EP'        => __('Expedited Parcel USA'),
                'USA.PW.ENV'    => __('Priority Worldwide Envelope USA'),
                'USA.PW.PAK'    => __('Priority Worldwide pak USA'),
                'USA.PW.PARCEL' => __('Priority Worldwide Parcel USA'),
                'USA.SP.AIR'    => __('Small Packet USA Air'),
                'USA.TP'        => __('Tracked Packet – USA'),
                'USA.TP.LVM'    => __('Tracked Packet – USA (LVM)'),
                'USA.XP'        => __('Xpresspost USA'),
                //international
                'INT.IP.AIR'    => __('International Parcel Air'),
                'INT.IP.SURF'   => __('International Parcel Surface'),
                'INT.XP'        => __('Xpresspost International'),
                'INT.PW.ENV'    => __('Priority Worldwide Envelope Int’l'),
                'INT.PW.PAK'    => __('Priority Worldwide pak Int’l'),
                'INT.PW.PARCEL' => __('Priority Worldwide parcel Int’l'),
                'INT.SP.AIR'    => __('Small Packet International Air'),
                'INT.SP.SURF'   => __('Small Packet International Surface'),
                'INT.TP'        => __('Tracked Packet – International')
            ]
        ];

        if (!isset($codes[$type])) {
            return false;
        } elseif ('' === $code) {
            return $codes[$type];
        }

        if (!isset($codes[$type][$code])) {
            return false;
        } else {
            return $codes[$type][$code];
        }
    }
    
    public function requestToShipment($request)
    {
        $packages = $request->getPackages();
        if (!is_array($packages) || !$packages) {
            throw new \Magento\Framework\Exception\LocalizedException(__('No packages for request'));
        }
        
        foreach ($packages as $packageId => $package) {
            $request->setPackageId($packageId);
            $request->setPackagingType($package['params']['container']);
            $request->setPackageWeight($package['params']['weight']);
            $request->setPackageParams(new \Magento\Framework\DataObject($package['params']));
            $request->setPackageItems($package['items']);
            $packageRequests[] = clone $request;
        }
        
        $result = $this->_doShipmentRequest($request);
        
        $response = new \Magento\Framework\DataObject(
            [
                'info' => [
                    [
                        'tracking_number' => $result->getTrackingNumber(),
                        'label_content' => base64_decode($result->getShippingLabelContent()),
                    ],
                ],
            ]
        );
        $request->setMasterTrackingId($result->getTrackingNumber());
        
        return $response;
    }
    
    protected function _doShipmentRequest(\Magento\Framework\DataObject $request)
    {
        $result = new \Magento\Framework\DataObject();
        $response = $this->_createShipmentRequest($request);
        
        return $response;
    }
    
    protected function _createShipmentRequest($request)
    {
        $senderAddress2 = $request->getShipperAddressStreet2() ? substr($request->getShipperAddressStreet2(), 0, 44) : '';
        $destinationCompany = $request->getRecipientContactCompanyName() ? substr($request->getRecipientContactCompanyName(), 0, 44) : '';
        $destinationAddress2 = $request->getRecipientAddressStreet2() ? substr($request->getRecipientAddressStreet2(), 0, 44) : '';
        
        $packageParams = $request->getPackageParams();
        $weight = $this->convertWeightToKg($request->getPackageWeight(), $packageParams->getWeightUnits());
        $height = $this->convertDimensionToCm($packageParams->getHeight(), $packageParams->getDimensionUnits());
        $width = $this->convertDimensionToCm($packageParams->getWidth(), $packageParams->getDimensionUnits());
        $length = $this->convertDimensionToCm($packageParams->getLength(), $packageParams->getDimensionUnits());
        
        $delivery_spec = [
            'service-code' => $request->getShippingMethod(),
            'sender' => [
                'company' => substr($request->getShipperContactCompanyName(), 0, 44),
                'contact-phone' => $request->getShipperContactPhoneNumber(),
                'address-details'   => [
                    'address-line-1' => substr($request->getShipperAddressStreet1(), 0, 44),
                    'address-line-2' => $senderAddress2,
                    'city' => substr($request->getShipperAddressCity(), 0, 40),
                    'prov-state' => $request->getShipperAddressStateOrProvinceCode(),
                    'postal-zip-code' => $this->formatPostalCode($request->getShipperAddressPostalCode())
                ]
            ],
            'destination' => [
                'name' => substr($request->getRecipientContactPersonName(), 0, 44),
                'company' => $destinationCompany,
                'client-voice-number' => $request->getRecipientContactPhoneNumber(),
                'address-details' => [
                    'address-line-1' => substr($request->getRecipientAddressStreet1(), 0, 44),
                    'address-line-2' => $destinationAddress2,
                    'city' => substr($request->getRecipientAddressCity(), 0, 40),
                    'prov-state' => $request->getRecipientAddressStateOrProvinceCode(),
                    'country-code' => $request->getRecipientAddressCountryCode(),
                    'postal-zip-code' => $this->formatPostalCode($request->getRecipientAddressPostalCode())
                ]
            ],
            'options' => [
                'option' => [
                    'option-code' => 'DC'
                ]
            ],
            'parcel-characteristics' => [
                'weight' => $weight,
                'unpackaged' => false,
                'mailing-tube'=> false
            ],
            'notification'  => [
                'email'         => $request->getRecipientEmail(),
                'on-shipment'   => true,
                'on-exception'  => false,
                'on-delivery'   => true
            ],
            'preferences' => [
                'show-packing-instructions' => true
            ]
        ];
        
        
        if ($length || $width || $height) {
            $delivery_spec['parcel-characteristics']['dimensions'] = [
                'length'    => $length,
                'width'     => $width,
                'height'    => $height
            ];
        }
        
        if ($request->getShipperAddressCountryCode() != $request->getRecipientAddressCountryCode()) {
            $reasonForExport = $this->customHelper->getConfig('carriers/rwcanadapost/reason_for_export');
            $destinationCurrency = $this->customHelper->getCurrencyByCountries($request->getRecipientAddressCountryCode());
            $currencyRate = $this->customHelper->getCurrencyRate(
                $request->getBaseCurrencyCode(),
                $destinationCurrency
            );
            if (!$currencyRate) {
                $destinationCurrency = $request->getBaseCurrencyCode();
                $currencyRate = 1;
            }
            $delivery_spec['customs'] = [
                'currency' => $destinationCurrency,
                'conversion-from-cad' => $currencyRate,
                'reason-for-export' => $reasonForExport,
                'sku-list' => [
                    'item' => $this->getSkuList($request)
                ]
            ];
            if ($reasonForExport == 'OTH') {
                $othReason = $this->customHelper->getConfig('carriers/rwcanadapost/reason_for_export');
                $delivery_spec['customs']['other-reason'] = substr(
                    $this->customHelper->getConfig('carriers/rwcanadapost/other_reason_for_export'),
                    0,
                    44
                );
            }
        }
        
        $params = [
            'create-non-contract-shipment-request' => [
                'mailed-by' => $this->customHelper->getCustomerNumber(),
                'locale' => $this->customHelper->getLocale(),
                'non-contract-shipment' => [
                    'requested-shipping-point' => $this->formatPostalCode($request->getShipperAddressPostalCode()),
                    'delivery-spec' => $delivery_spec
                ]
            ]
        ];
        
        //echo '<pre>';print_r($params);exit;
        $wsdlFileName = '/libcanadapost/wsdl/ncshipment.wsdl';
        $client = $this->_createSoapClient($wsdlFileName, 'ncshipment');
        $response = $client->__soapCall('CreateNCShipment', $params, null, null);
        //echo '<pre>';print_r($response);exit;
        $result = new \Magento\Framework\DataObject();
        if (isset($response->{'non-contract-shipment-info'})) {
            $shippingLabelContent = $this->getCanadaPostLabelForNonContract($request, $response);
            if (isset($response->{'non-contract-shipment-info'}->{'tracking-pin'})) {
                $trackingNumber = $response->{'non-contract-shipment-info'}->{'tracking-pin'};
            } else {
                $trackingNumber = __('N/A');
            }
            $result->setShippingLabelContent($shippingLabelContent);
            $result->setTrackingNumber($trackingNumber);
        } else {
            $errorMsg = __('');
            if (is_array($response) && isset($response['error_message'])) {
                $errorMsg = $response['error_message'];
            }
            if (is_object($response) && $response->{'messages'}) {
                foreach ($response->{'messages'}->{'message'} as $message) {
                    if (is_array($message)){
                        $message = $message[0];
                    } else {
                        $message = $message;
                    }
                    if (isset($message->code) && isset($message->description) ) {
                        $errorMsg = 'Error Code = '.$message->code.': Error Message = '.$message->description;
                    }
                }
            }
            throw new \Magento\Framework\Exception\LocalizedException(
                __($errorMsg)
            );
        }
        
        return $result;
    }
    
    protected function getCanadaPostLabelForNonContract($rawRequest, $response)
    {
        $labelId ='';
        $pageIndex = '';
        foreach ($response->{'non-contract-shipment-info'}->{'artifacts'}->{'artifact'} as $artifact) {
            $labelId =  $artifact->{'artifact-id'};
            $pageIndex =  $artifact->{'page-index'};
        }
        $wsdlFileName = '/libcanadapost/wsdl/artifact.wsdl';
        $client = $this->_createSoapClient($wsdlFileName, 'artifact');
        try {
            $result = $client->__soapCall(
                'GetArtifact',
                [
                    'get-artifact-request' => [
                        'locale'            => $this->customHelper->getLocale(),
                        'mailed-by'         => '0008640259',
                        'artifact-id'       => $labelId,
                        'page-index'        => $pageIndex
                    ]
                ],
                null,
                null
            );
        } catch (\Exception $e) {
            throw new \Magento\Framework\Exception\LocalizedException(__($e->getMessage()));
        }
        if (isset($result->{'artifact-data'})) {
            return $result->{'artifact-data'}->{'image'};
        } else {
            if (isset($response['error_message'])) {
                throw new \Magento\Framework\Exception\LocalizedException(
                    __($response['error_message'])
                );
            }
        }
    }
    
    protected function getSkuList($request)
    {
        $weightUnit = $this->customHelper->getWeightUnit();
        $skus = array();
        foreach ($request->getPackageItems() as $itemShipment) {
            $_product = $this->_productRepository->getById($itemShipment['product_id']);
            $unitWeight = $this->convertWeightToKg(
                $itemShipment['weight'],
                $weightUnit
            );

            $data = [
                'sku' => substr($_product->getSku(), 0, 15),
                'customs-description' => substr($itemShipment['name'], 0, 45),
                'unit-weight' => $unitWeight,
                'customs-value-per-unit' => round($itemShipment['customs_value'], 2),
                'customs-number-of-units' => $itemShipment['qty'],
            ];

            if ($_product->getCountryOfManufacture()) {
                $data['country-of-origin'] = $_product->getCountryOfManufacture();
            }

            $skus[] = $data;
        }
        
        return $skus;
    }
    
    protected function _createSoapClient($wsdlFileName, $type)
    {
        ini_set('soap.wsdl_cache_enabled', 0);
        $appDir = $this->customHelper->getDirectory();        
        $hostName = $this->customHelper->getHostName();
        $wsdl =  $appDir . $wsdlFileName;
        $cert = $appDir.'/libcanadapost/cert/cacert.pem';
        
        if ($type == 'rating') {
            $location = 'https://' . $hostName . '/rs/soap/rating/v4';
        }

        if ($type == 'shipment') {
            $location = 'https://' . $hostName . '/rs/soap/shipment/v8';
        }

        if ($type == 'track') {
            $location = 'https://' . $hostName . '/vis/soap/track';
        }

        if ($type == 'ncshipment') {
            $location = 'https://' . $hostName . '/rs/soap/ncshipment/v4';
        }

        if ($type == 'artifact') {
            $location = 'https://' . $hostName . '/rs/soap/artifact';
        }
        
        if ($type == 'pickup') {
            $location = 'https://' . $hostName . '/ad/soap/pickup/availability';
        }
        
        if ($type == 'postoffice') {
            $location = 'https://' . $hostName . '/rs/soap/postoffice';
        }

        $options = [
            'location' => $location,
            'features' => SOAP_SINGLE_ELEMENT_ARRAYS,
            'trace'=>0
        ];

        $opts = ['ssl' =>
            [
                'verify_peer'=> false,
                'cafile' => $cert,
                'CN_match' => $hostName
            ],
            'http' => [
                'protocol_version' => 1.0,
            ]
        ];

        $ctx = stream_context_create($opts);
        $options['stream_context'] = $ctx;
        
        $client = new \Rootways\Canadapost\Model\Service\SoapClient($wsdl, $type, $options);
        // Set WS Security UsernameToken
        $WSSENS = 'http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd';
        $usernameToken = new \stdClass();
        $usernameToken->Username = new \SoapVar($this->customHelper->getApiKey(), XSD_STRING, null, null, null, $WSSENS);
        $usernameToken->Password = new \SoapVar($this->customHelper->getPassword(), XSD_STRING, null, null, null, $WSSENS);
        $content = new \stdClass();
        $content->UsernameToken = new \SoapVar($usernameToken, SOAP_ENC_OBJECT, null, null, null, $WSSENS);
        $header = new \SOAPHeader($WSSENS, 'Security', $content);
        $client->__setSoapHeaders($header);
        return $client;
    }
    
    
    public function getTracking($trackNumber)
    {
        $trackingResuls = $this->_trackFactory->create();
        
        $params = [
            'get-tracking-detail-request' => [
                'locale' => $this->customHelper->getLocale(),
                'pin' => $trackNumber
            ]
        ];
        $wsdlFileName = '/libcanadapost/wsdl/track.wsdl';
        $client = $this->_createSoapClient($wsdlFileName, 'track');
        $response = $client->__soapCall('GetTrackingDetail', $params, null, null);
        
        /*
        // Below are parameters for get tracking summary
        $params = [
            'get-tracking-summary-request' => [
                'locale' => $this->customHelper->getLocale(),
                'pin' => $trackNumber
            ]
        ];
        $wsdlFileName = '/libcanadapost/wsdl/track.wsdl';
        $client = $this->_createSoapClient($wsdlFileName, 'track');
        $response = $client->__soapCall('GetTrackingSummary', $params, null, null);
        */
        /*
        // Below are parameters for get nearest post offices.
        $params = [
            'get-nearest-post-office-request' => [
                'locale' => $this->customHelper->getLocale(),
                'maximum' =>  '5',
                'search-data' => array (
                    // 'city'			=> 'Ottawa',
                    'postal-code'	=> 'K2B8J6'
                    // 'province'		=> 'ON',
                    // 'street-name'	=> 'Richmond'	
                )
            ]
        ];
        
        $wsdlFileName = '/libcanadapost/wsdl/postoffice.wsdl';
        $client = $this->_createSoapClient($wsdlFileName, 'postoffice');
        $response = $client->__soapCall('GetNearestPostOffice', $params, null, null);
        */
        
        /*
        // Below are parameters for get post office detail.
        $params = [
            'get-post-office-detail-request' => [
                'locale' => $this->customHelper->getLocale(),
                'office-id' =>  '0000105040'
            ]
        ];
        
        $wsdlFileName = '/libcanadapost/wsdl/postoffice.wsdl';
        $client = $this->_createSoapClient($wsdlFileName, 'postoffice');
        $response = $client->__soapCall('GetPostOfficeDetail', $params, null, null);
        */
        
        //echo '<pre>';print_r($params);
        //echo '<pre>';print_r($response);exit;
        

        if (isset($response->{'tracking-detail'})) {
            $tracking = $this->_trackStatusFactory->create();
            $tracking->setCarrier($this->_code);
            $tracking->setCarrierTitle($this->customHelper->getConfig('carriers/rwcanadapost/title'));
            $tracking->setTracking($trackNumber);
            
            //$tracking->setTrackSummary($trackingResulsFromService->summary);
            //$tracking->addData($this->processTrackingDetails($trackInfo));
            
            $trackingResuls->append($tracking);
        } else {
            $error = $this->_trackErrorFactory->create();
            $error->setCarrier($this->_code);
            $error->setCarrierTitle($this->customHelper->getConfig('carriers/rwcanadapost/title'));
            $error->setTracking($trackNumber);
            $error->setErrorMessage('Error while retrieving tracking info.');
            $trackingResuls->append($error);
        }

        return $trackingResuls;
        
    }
    
    public function formatPostalCode($postalCode)
    {
        return strtoupper(preg_replace('/\s+/', '', $postalCode));
    }
    
    public function convertWeightToKg($weight, $weightUnit, $roundPrecision = 3)
    {
        return round(
            $this->customHelper->convertMeasureWeight(
                $weight,
                $weightUnit,
                \Zend_Measure_Weight::KILOGRAM
            ),
            $roundPrecision
        );
    }
    
    public function convertDimensionToCm($dimension, $dimensionUnit, $roundPrecision = 1)
    {
        return round(
            $this->customHelper->convertMeasureDimension(
                $dimension,
                $dimensionUnit,
                \Zend_Measure_Length::CENTIMETER
            ),
            $roundPrecision
        );
    }
}
