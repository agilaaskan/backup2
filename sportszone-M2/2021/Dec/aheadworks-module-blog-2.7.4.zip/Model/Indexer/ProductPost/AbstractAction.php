<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Blog
 * @version    2.7.4
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Blog\Model\Indexer\ProductPost;

use Aheadworks\Blog\Model\ResourceModel\Indexer\ProductPost as ResourceProductPostIndexer;

/**
 * Class AbstractAction
 * @package Aheadworks\Blog\Model\Indexer\ProductPost
 */
abstract class AbstractAction
{
    /**
     * @var ResourceProductPostIndexer
     */
    protected $resourceProductPostIndexer;

    /**
     * @param ResourceProductPostIndexer $resourceProductPostIndexer
     */
    public function __construct(
        ResourceProductPostIndexer $resourceProductPostIndexer
    ) {
        $this->resourceProductPostIndexer = $resourceProductPostIndexer;
    }

    /**
     * Execute action for given ids
     *
     * @param array|int $ids
     * @return void
     */
    abstract public function execute($ids);
}
